const UserService = require('./UserService');

module.exports = {
    UserService
}
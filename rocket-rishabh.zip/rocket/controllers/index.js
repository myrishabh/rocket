const UserController = require("./UserController");

module.exports = {UserController}